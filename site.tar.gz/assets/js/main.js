/* Sergio Gonçalves — interações essenciais: menu móvel, submenu e acordeão.
   O conteúdo continua disponível sem JavaScript. */
(function () {
  'use strict';
  var root = document.documentElement;
  var header = document.querySelector('.site-header');

  function setHeaderH() { if (header) root.style.setProperty('--header-h', header.offsetHeight + 'px'); }
  setHeaderH();
  window.addEventListener('resize', setHeaderH);

  // Divisória do cabeçalho aparece após a rolagem (home)
  if (header) {
    var onScroll = function () { header.classList.toggle('is-scrolled', window.scrollY > 8); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Menu móvel */
  var menuBtn = document.querySelector('.menu-button');
  var menu = document.getElementById('mobile-menu');
  var inertTargets = [document.getElementById('conteudo'), document.querySelector('.site-footer'), document.querySelector('.skip-link'), document.querySelector('.review-bar')].filter(Boolean);
  function setMenu(open, returnFocus) {
    if (!menuBtn || !menu) return;
    menuBtn.setAttribute('aria-expanded', String(open));
    menuBtn.querySelector('.menu-label').textContent = open ? 'Fechar menu' : 'Abrir menu';
    menuBtn.querySelector('.icon-open').style.display = open ? 'none' : '';
    menuBtn.querySelector('.icon-close').style.display = open ? '' : 'none';
    menu.hidden = !open;
    document.body.classList.toggle('menu-open', open);
    inertTargets.forEach(function (el) { if (open) el.setAttribute('inert', ''); else el.removeAttribute('inert'); });
    if (open) { var first = menu.querySelector('a'); if (first) first.focus(); }
    else if (returnFocus) menuBtn.focus();
  }
  if (menuBtn && menu) {
    menuBtn.addEventListener('click', function () { setMenu(menuBtn.getAttribute('aria-expanded') !== 'true', true); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && menuBtn.getAttribute('aria-expanded') === 'true') setMenu(false, true);
    });
    header.addEventListener('keydown', function (e) {
      if (e.key !== 'Tab' || menuBtn.getAttribute('aria-expanded') !== 'true') return;
      var items = [].slice.call(header.querySelectorAll('a[href], button')).filter(function (el) { return el.offsetParent !== null; });
      var first = items[0], last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
    var mq = window.matchMedia('(min-width: 1100px)');
    var onMq = function (ev) { if (ev.matches) setMenu(false, false); };
    if (mq.addEventListener) mq.addEventListener('change', onMq); else mq.addListener(onMq);
  }

  /* ---------- Submenu de Serviços (clique e teclado) */
  document.querySelectorAll('[data-submenu-toggle]').forEach(function (btn) {
    var panel = document.getElementById(btn.getAttribute('aria-controls'));
    var wrap = btn.parentElement;
    btn.hidden = false;
    panel.hidden = true;
    function set(open) { btn.setAttribute('aria-expanded', String(open)); panel.hidden = !open; }
    btn.addEventListener('click', function () { set(btn.getAttribute('aria-expanded') !== 'true'); });
    wrap.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && btn.getAttribute('aria-expanded') === 'true') { set(false); btn.focus(); }
    });
    document.addEventListener('click', function (e) { if (!wrap.contains(e.target)) set(false); });
    wrap.addEventListener('focusout', function (e) { if (e.relatedTarget && !wrap.contains(e.relatedTarget)) set(false); });
  });

  /* ---------- Acordeão (várias respostas podem ficar abertas) */
  document.querySelectorAll('[data-accordion] .accordion-trigger').forEach(function (btn) {
    var panel = document.getElementById(btn.getAttribute('aria-controls'));
    btn.setAttribute('aria-expanded', 'false');
    panel.hidden = true;
    btn.addEventListener('click', function () {
      var open = btn.getAttribute('aria-expanded') !== 'true';
      btn.setAttribute('aria-expanded', String(open));
      panel.hidden = !open;
      panel.classList.toggle('is-open', open);
    });
  });
})();
