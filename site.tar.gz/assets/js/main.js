/* Sergio Gonçalves — interações essenciais: menu móvel, submenu e acordeão.
   O conteúdo continua disponível sem JavaScript. */
(function () {
  'use strict';
  var root = document.documentElement;
  var header = document.querySelector('.site-header');

  function setHeaderH() { if (header) root.style.setProperty('--header-h', header.offsetHeight + 'px'); }
  setHeaderH();
  window.addEventListener('resize', setHeaderH);

  // Divisória do cabeçalho aparece após a rolagem (home)
  if (header) {
    var onScroll = function () { header.classList.toggle('is-scrolled', window.scrollY > 8); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Menu móvel */
  var menuBtn = document.querySelector('.menu-button');
  var menu = document.getElementById('mobile-menu');
  var inertTargets = [document.getElementById('conteudo'), document.querySelector('.site-footer'), document.querySelector('.skip-link'), document.querySelector('.review-bar')].filter(Boolean);
  function setMenu(open, returnFocus) {
    if (!menuBtn || !menu) return;
    menuBtn.setAttribute('aria-expanded', String(open));
    menuBtn.querySelector('.menu-label').textContent = open ? 'Fechar menu' : 'Abrir menu';
    menuBtn.querySelector('.icon-open').style.display = open ? 'none' : '';
    menuBtn.querySelector('.icon-close').style.display = open ? '' : 'none';
    menu.hidden = !open;
    document.body.classList.toggle('menu-open', open);
    inertTargets.forEach(function (el) { if (open) el.setAttribute('inert', ''); else el.removeAttribute('inert'); });
    if (open) { var first = menu.querySelector('a'); if (first) first.focus(); }
    else if (returnFocus) menuBtn.focus();
  }
  if (menuBtn && menu) {
    menuBtn.addEventListener('click', function () { setMenu(menuBtn.getAttribute('aria-expanded') !== 'true', true); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && menuBtn.getAttribute('aria-expanded') === 'true') setMenu(false, true);
    });
    header.addEventListener('keydown', function (e) {
      if (e.key !== 'Tab' || menuBtn.getAttribute('aria-expanded') !== 'true') return;
      var items = [].slice.call(header.querySelectorAll('a[href], button')).filter(function (el) { return el.offsetParent !== null; });
      var first = items[0], last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
    var mq = window.matchMedia('(min-width: 1100px)');
    var onMq = function (ev) { if (ev.matches) setMenu(false, false); };
    if (mq.addEventListener) mq.addEventListener('change', onMq); else mq.addListener(onMq);
  }

  /* ---------- Submenu de Serviços (clique e teclado) */
  document.querySelectorAll('[data-submenu-toggle]').forEach(function (btn) {
    var panel = document.getElementById(btn.getAttribute('aria-controls'));
    var wrap = btn.parentElement;
    btn.hidden = false;
    panel.hidden = true;
    function set(open) { btn.setAttribute('aria-expanded', String(open)); panel.hidden = !open; }
    btn.addEventListener('click', function () { set(btn.getAttribute('aria-expanded') !== 'true'); });
    wrap.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && btn.getAttribute('aria-expanded') === 'true') { set(false); btn.focus(); }
    });
    document.addEventListener('click', function (e) { if (!wrap.contains(e.target)) set(false); });
    wrap.addEventListener('focusout', function (e) { if (e.relatedTarget && !wrap.contains(e.relatedTarget)) set(false); });
  });

  /* ---------- Acordeão (várias respostas podem ficar abertas) */
  document.querySelectorAll('[data-accordion] .accordion-trigger').forEach(function (btn) {
    var panel = document.getElementById(btn.getAttribute('aria-controls'));
    btn.setAttribute('aria-expanded', 'false');
    panel.hidden = true;
    btn.addEventListener('click', function () {
      var open = btn.getAttribute('aria-expanded') !== 'true';
      btn.setAttribute('aria-expanded', String(open));
      panel.hidden = !open;
      panel.classList.toggle('is-open', open);
    });
  });

  /* ---------- Movimento: revelação ao rolar e paralaxe leve (desligados com movimento reduzido) */
  if (root.classList.contains('motion')) {
    var sel = [
      'main .section h2', 'main .section .section-head .lead', 'main .section .lead', '.svc-block', '.svc-item', '.flow > li', '.routine > li',
      '.principles > li', '.rows > li', '.qa > div', '.related > li', '.portrait', '.highlight', '.accordion-item',
      '.legal section', '.legal-toc', '.tips', '.contact-card', '.closing-copy .actions', '.closing-copy .contact-direct', '.photo-band__content > *'
    ].join(',');
    var targets = [].slice.call(document.querySelectorAll(sel)).filter(function (el) {
      return !el.closest('.photo-hero') && !el.closest('[data-reveal]:not(.contact-card)') && !el.closest('.site-header') && !el.closest('.mobile-menu');
    });
    targets.forEach(function (el) {
      el.setAttribute('data-reveal', '');
      var sib = el.parentElement ? [].slice.call(el.parentElement.children).filter(function (c) { return c.hasAttribute('data-reveal'); }) : [];
      var i = sib.indexOf(el);
      if (i > 0) el.style.setProperty('--d', Math.min(i, 5) * 80 + 'ms');
    });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.08 });
    document.querySelectorAll('[data-reveal]').forEach(function (el) { io.observe(el); });

    // Paralaxe: só em telas largas; a imagem anda mais devagar que a página.
    var wide = window.matchMedia('(min-width: 1100px)');
    var layers = [];
    document.querySelectorAll('.photo-hero').forEach(function (h) { h.classList.add('parallax-on'); layers.push({ box: h, img: h.querySelector('.photo-hero__media img'), k: 0.22, hero: true }); });
    document.querySelectorAll('.photo-band__media').forEach(function (m) { m.classList.add('parallax-on'); layers.push({ box: m.parentElement, img: m.querySelector('img'), k: 0.12 }); });
    var ticking = false;
    function update() {
      ticking = false;
      if (!wide.matches) { layers.forEach(function (l) { if (l.img) l.img.style.removeProperty('--py'); }); return; }
      var vh = window.innerHeight;
      layers.forEach(function (l) {
        if (!l.img) return;
        var r = l.box.getBoundingClientRect();
        if (r.bottom < 0 || r.top > vh) return;
        var max = r.height * 0.09;
        var y = l.hero ? -r.top * l.k : (r.top + r.height / 2 - vh / 2) * -l.k;
        y = Math.max(-max, Math.min(max, y));
        l.img.style.setProperty('--py', y.toFixed(1) + 'px');
      });
    }
    function onScroll() { if (!ticking) { ticking = true; window.requestAnimationFrame(update); } }
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    update();
  }
})();
